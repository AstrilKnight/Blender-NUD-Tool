================
Blender NUD Tool
================

Tool for editing the nud file format within blender.

**Install**

Open User preferences in blender, under add-on tab select install from file. 
Locate the zip file and accept. Find the add-on and check NUD Tool. 
To load add-on when Blender starts click Save User Settings.